AFM-Fold final clean manuscript source

Manuscript ID: BIOPHYSICAL-JOURNAL-D-25-00813R1

This flat package is intended for submission systems that reject
LaTeX source trees containing subdirectories.

Contents:
- biophysj.tex: single-file LaTeX source with local inputs expanded
- biophysj.pdf: clean final manuscript PDF without embedded figures
- biophys-new.cls: Biophysical Journal class file
- biophysj.bst: BibTeX style file required by Editorial Manager
- citation_biophysj.bib: bibliography database
- biophysj.bbl: generated bibliography for the manuscript
- biophysj_SI.aux: cross-reference labels from the Supplemental Material

Separate figure files and the composite Supplemental Material PDF
should be uploaded separately, as requested by the journal.
